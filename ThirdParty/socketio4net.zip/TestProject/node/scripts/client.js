var viewModel = {
    name: ko.observable(""),
    area: "",
    data: ""
};
